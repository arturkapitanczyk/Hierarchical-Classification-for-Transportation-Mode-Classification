# Project Name

This project is an implementation of a hierarchical classifier and flat classifier for transportation mode classification. It uses the SHL dataset and logistic regression.

## Python Version

This project was developed using Python 3.10.11.

## Packages Utilized

joblib==1.2.0
numpy==1.23.4
pandas==1.5.3
python-dateutil==2.8.2
pytz==2022.7.1
scikit-learn==1.2.1
scipy==1.9.3
six==1.16.0
sklearn==0.0.post1

In order to be able to run the code, the data needs to be downloaded from the SHL dataset 
http://www.shl-dataset.org/download/ 
Download from the SHL Complete User 1 – Hips phone link
Change path within np.loadtxt() functions at the start of the hierarchicalclassifier.py and flatclassifier.py files

For testing different imbalanced datasets:
Change the first definition of dftrain and dftest with different combinations of days that result in non-motorized data heavy, balanced or motorized data heavy datasets.

Non-motorized training set: df27, df26, df16
Balanced training set: df7, df17, df27, df9
Motorized training set: df28, df31, df3

Non-motorized testing set: df4, df10
Balanced testing set: df4, df14
Motorized testing set: df13, df23