from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report

def category(x):
    if (x > 4) or (x==1):
        return 2
    else:
        return 1

#loading in raw data without labels
data = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\010317\Hips_Motion.txt", delimiter=' ')
data2 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\010617\Hips_Motion.txt", delimiter=' ')
data3 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020317\Hips_Motion.txt", delimiter=' ')
data4 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020517\Hips_Motion.txt", delimiter=' ')
data5 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020617\Hips_Motion.txt", delimiter=' ')
data6 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030317\Hips_Motion.txt", delimiter=' ')
data7 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030517\Hips_Motion.txt", delimiter=' ')
data8 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030617\Hips_Motion.txt", delimiter=' ')
data9 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030717\Hips_Motion.txt", delimiter=' ')
data10 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\040517\Hips_Motion.txt", delimiter=' ')
data11 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\040717\Hips_Motion.txt", delimiter=' ')
data12 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\050517\Hips_Motion.txt", delimiter=' ')
#naming the 23 columns of data
df = pd.DataFrame(data, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df2 = pd.DataFrame(data2, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df3 = pd.DataFrame(data3, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df4 = pd.DataFrame(data4, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df5 = pd.DataFrame(data5, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df6 = pd.DataFrame(data6, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df7 = pd.DataFrame(data7, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df8 = pd.DataFrame(data8, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df9 = pd.DataFrame(data9, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df10 = pd.DataFrame(data10, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df11 = pd.DataFrame(data11, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df12 = pd.DataFrame(data12, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])


#loading in labels for the data
datalabel = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\010317\label.txt", delimiter=' ')
datalabel2 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\010617\label.txt", delimiter=' ')
datalabel3 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020317\label.txt", delimiter=' ')
datalabel4 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020517\label.txt", delimiter=' ')
datalabel5 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020617\label.txt", delimiter=' ')
datalabel6 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030317\label.txt", delimiter=' ')
datalabel7 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030517\label.txt", delimiter=' ')
datalabel8 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030617\label.txt", delimiter=' ')
datalabel9 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030717\label.txt", delimiter=' ')
datalabel10 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\040517\label.txt", delimiter=' ')
datalabel11 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\040717\label.txt", delimiter=' ')
datalabel12 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\050517\label.txt", delimiter=' ')

#adding the label of the data as a new column to the dataframe
dflabel = pd.DataFrame(datalabel, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel2 = pd.DataFrame(datalabel2, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel3 = pd.DataFrame(datalabel3, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel4 = pd.DataFrame(datalabel4, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel5 = pd.DataFrame(datalabel5, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel6 = pd.DataFrame(datalabel6, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel7 = pd.DataFrame(datalabel7, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel8 = pd.DataFrame(datalabel8, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel9 = pd.DataFrame(datalabel9, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel10 = pd.DataFrame(datalabel10, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel11 = pd.DataFrame(datalabel11, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel12 = pd.DataFrame(datalabel12, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])

df['Label'] = dflabel['CourseLabel']
df2['Label'] = dflabel2['CourseLabel']
df3['Label'] = dflabel3['CourseLabel']
df4['Label'] = dflabel4['CourseLabel']
df5['Label'] = dflabel5['CourseLabel']
df6['Label'] = dflabel6['CourseLabel']
df7['Label'] = dflabel7['CourseLabel']
df8['Label'] = dflabel8['CourseLabel']
df9['Label'] = dflabel9['CourseLabel']
df10['Label'] = dflabel10['CourseLabel']
df11['Label'] = dflabel11['CourseLabel']
df12['Label'] = dflabel12['CourseLabel']

#Null=0, Still=1, Walking=2, Run=3, Bike=4, Car=5, Bus=6, Train=7, Subway=8
alldata = pd.concat([df, df2, df3, df4, df5, df6, df7, df8, df9, df10, df11, df12], axis=0)
#removing null values
alldata = alldata.dropna()
#removing values with null labels
alldata = alldata[alldata['Label'] > 0]
alldata['Category'] = alldata['Label'].apply(category)


#calculating statistics
grouped_data = alldata.groupby(np.arange(len(alldata))//300)
stat_df_acceleration = pd.DataFrame(columns=['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max',
                                 'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'label'])
stat_df_gyroscope = pd.DataFrame(columns=['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max',
                                 'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'label'])
stat_df_magnometer = pd.DataFrame(columns=['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max',
                                 'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'label'])
stat_df_orientation = pd.DataFrame(columns=['w_mean', 'x_mean', 'y_mean', 'z_mean','w_std', 'x_std', 'y_std', 'z_std','w_average_absolute_diff', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'w_min', 'x_min', 'y_min', 'z_min', 'w_max', 'x_max', 'y_max',
                                 'z_max', 'w_maxmin_diff', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'w_median', 'x_median', 'y_median', 'z_median', 'w_mad', 'x_mad', 'y_mad', 'z_mad', 'w_IQR', 'x_IQR', 'y_IQR', 'z_IQR', 'label'])
stat_df_gravity = pd.DataFrame(columns=['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max',
                                 'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'label'])
stat_df_lacceleration = pd.DataFrame(columns=['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max',
                                 'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'label'])
stat_df_pressure = pd.DataFrame(columns=['mean', 'std', 'average_absolute_diff', 'min', 'max', 'maxmin_diff', 'median', 'mad', 'IQR', 'label'])
stat_df_altitude = pd.DataFrame(columns=['mean', 'std', 'average_absolute_diff', 'min', 'max', 'maxmin_diff', 'median', 'mad', 'IQR', 'label'])
stat_df_temperature = pd.DataFrame(columns=['mean', 'std', 'average_absolute_diff', 'min', 'max', 'maxmin_diff', 'median', 'mad', 'IQR', 'label'])

for i, g in grouped_data:
    
    x_mean = g['AccelerationX'].mean()
    y_mean = g['AccelerationY'].mean()
    z_mean = g['AccelerationZ'].mean()

    x_std = g['AccelerationX'].std()
    y_std = g['AccelerationY'].std()
    z_std = g['AccelerationZ'].std()

    x_average_absolute_diff = (abs(g['AccelerationX'] - g['AccelerationX'].mean())).mean()
    y_average_absolute_diff = (abs(g['AccelerationY'] - g['AccelerationY'].mean())).mean()
    z_average_absolute_diff = (abs(g['AccelerationZ'] - g['AccelerationZ'].mean())).mean()

    x_min = g['AccelerationX'].min()
    y_min = g['AccelerationY'].min()
    z_min = g['AccelerationZ'].min()

    x_max = g['AccelerationX'].max()
    y_max = g['AccelerationY'].max()
    z_max = g['AccelerationZ'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min

    x_median = g['AccelerationX'].median()
    y_median = g['AccelerationY'].median()
    z_median = g['AccelerationZ'].median()

    x_mad = (abs(g['AccelerationX'] - x_median)).median()
    y_mad = (abs(g['AccelerationY'] - y_median)).median()
    z_mad = (abs(g['AccelerationZ'] - z_median)).median()

    x_IQR = g['AccelerationX'].describe()['75%'] - g['AccelerationX'].describe()['25%']
    y_IQR = g['AccelerationY'].describe()['75%'] - g['AccelerationY'].describe()['25%']
    z_IQR = g['AccelerationZ'].describe()['75%'] - g['AccelerationZ'].describe()['25%']

    #calculate most common label in the window
    label = g['Category'].max()

    new_row = [x_mean, y_mean, z_mean, x_std, y_std, z_std, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff, 
                        x_min, y_min, z_min, x_max, y_max, z_max, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, x_median, y_median, z_median, x_mad, 
                        y_mad, z_mad, x_IQR, y_IQR, z_IQR, label]

    stat_df_acceleration.loc[len(stat_df_acceleration)] = new_row
    
for i, g in grouped_data:
    
    x_mean = g['GyroscopeX'].mean()
    y_mean = g['GyroscopeY'].mean()
    z_mean = g['GyroscopeZ'].mean()

    x_std = g['GyroscopeX'].std()
    y_std = g['GyroscopeY'].std()
    z_std = g['GyroscopeZ'].std()

    x_average_absolute_diff = (abs(g['GyroscopeX'] - g['GyroscopeX'].mean())).mean()
    y_average_absolute_diff = (abs(g['GyroscopeY'] - g['GyroscopeY'].mean())).mean()
    z_average_absolute_diff = (abs(g['GyroscopeZ'] - g['GyroscopeZ'].mean())).mean()

    x_min = g['GyroscopeX'].min()
    y_min = g['GyroscopeY'].min()
    z_min = g['GyroscopeZ'].min()

    x_max = g['GyroscopeX'].max()
    y_max = g['GyroscopeY'].max()
    z_max = g['GyroscopeZ'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min

    x_median = g['GyroscopeX'].median()
    y_median = g['GyroscopeY'].median()
    z_median = g['GyroscopeZ'].median()

    x_mad = (abs(g['GyroscopeX'] - x_median)).median()
    y_mad = (abs(g['GyroscopeY'] - y_median)).median()
    z_mad = (abs(g['GyroscopeZ'] - z_median)).median()

    x_IQR = g['GyroscopeX'].describe()['75%'] - g['GyroscopeX'].describe()['25%']
    y_IQR = g['GyroscopeY'].describe()['75%'] - g['GyroscopeY'].describe()['25%']
    z_IQR = g['GyroscopeZ'].describe()['75%'] - g['GyroscopeZ'].describe()['25%']

    #calculate most common label in the window
    label = g['Category'].max()

    new_row = [x_mean, y_mean, z_mean, x_std, y_std, z_std, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff, x_min, y_min, z_min, x_max, y_max, z_max, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, x_median, y_median, z_median, x_mad,                         y_mad, z_mad, x_IQR, y_IQR, z_IQR, label]

    stat_df_gyroscope.loc[len(stat_df_gyroscope)] = new_row

for i, g in grouped_data:

    x_mean = g['MagnometerX'].mean()
    y_mean = g['MagnometerY'].mean()
    z_mean = g['MagnometerZ'].mean()

    x_std = g['MagnometerX'].std()
    y_std = g['MagnometerY'].std()
    z_std = g['MagnometerZ'].std()

    x_average_absolute_diff = (abs(g['MagnometerX'] - g['MagnometerX'].mean())).mean()
    y_average_absolute_diff = (abs(g['MagnometerY'] - g['MagnometerY'].mean())).mean()
    z_average_absolute_diff = (abs(g['MagnometerZ'] - g['MagnometerZ'].mean())).mean()

    x_min = g['MagnometerX'].min()
    y_min = g['MagnometerY'].min()
    z_min = g['MagnometerZ'].min()

    x_max = g['MagnometerX'].max()
    y_max = g['MagnometerY'].max()
    z_max = g['MagnometerZ'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min

    x_median = g['MagnometerX'].median()
    y_median = g['MagnometerY'].median()
    z_median = g['MagnometerZ'].median()

    x_mad = (abs(g['MagnometerX'] - x_median)).median()
    y_mad = (abs(g['MagnometerY'] - y_median)).median()
    z_mad = (abs(g['MagnometerZ'] - z_median)).median()

    x_IQR = g['MagnometerX'].describe()['75%'] - g['MagnometerX'].describe()['25%']
    y_IQR = g['MagnometerY'].describe()['75%'] - g['MagnometerY'].describe()['25%']
    z_IQR = g['MagnometerZ'].describe()['75%'] - g['MagnometerZ'].describe()['25%']

    #calculate most common label in the window
    label = g['Category'].max()

    new_row = [x_mean, y_mean, z_mean, x_std, y_std, z_std, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff, 
                        x_min, y_min, z_min, x_max, y_max, z_max, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, x_median, y_median, z_median, x_mad, 
                        y_mad, z_mad, x_IQR, y_IQR, z_IQR, label]

    stat_df_magnometer.loc[len(stat_df_magnometer)] = new_row

for i, g in grouped_data:
    x_mean = g['OrientationX'].mean()
    y_mean = g['OrientationY'].mean()
    z_mean = g['OrientationZ'].mean()
    w_mean = g['OrientationW'].mean()

    x_std = g['OrientationX'].std()
    y_std = g['OrientationY'].std()
    z_std = g['OrientationZ'].std()
    w_std = g['OrientationW'].std()

    x_average_absolute_diff = (abs(g['OrientationX'] - g['OrientationX'].mean())).mean()
    y_average_absolute_diff = (abs(g['OrientationY'] - g['OrientationY'].mean())).mean()
    z_average_absolute_diff = (abs(g['OrientationZ'] - g['OrientationZ'].mean())).mean()
    w_average_absolute_diff = (abs(g['OrientationW'] - g['OrientationW'].mean())).mean()

    x_min = g['OrientationX'].min()
    y_min = g['OrientationY'].min()
    z_min = g['OrientationZ'].min()
    w_min = g['OrientationW'].min()

    x_max = g['OrientationX'].max()
    y_max = g['OrientationY'].max()
    z_max = g['OrientationZ'].max()
    w_max = g['OrientationW'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min
    w_maxmin_diff = w_max - w_min

    x_median = g['OrientationX'].median()
    y_median = g['OrientationY'].median()
    z_median = g['OrientationZ'].median()
    w_median = g['OrientationW'].median()

    x_mad = (abs(g['OrientationX'] - x_median)).median()
    y_mad = (abs(g['OrientationY'] - y_median)).median()
    z_mad = (abs(g['OrientationZ'] - z_median)).median()
    w_mad = (abs(g['OrientationW'] - w_median)).median()

    x_IQR = g['OrientationX'].describe()['75%'] - g['OrientationX'].describe()['25%']
    y_IQR = g['OrientationY'].describe()['75%'] - g['OrientationY'].describe()['25%']
    z_IQR = g['OrientationZ'].describe()['75%'] - g['OrientationZ'].describe()['25%']
    w_IQR = g['OrientationW'].describe()['75%'] - g['OrientationW'].describe()['25%']

    #calculate most common label in the window
    label = g['Category'].max()

    new_row = [w_mean, x_mean, y_mean, z_mean, w_std, x_std, y_std, z_std, w_average_absolute_diff, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff, w_min, x_min, y_min, z_min, w_max, x_max, y_max, z_max, w_maxmin_diff, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, w_median, x_median, y_median, z_median, w_mad, x_mad, y_mad, z_mad, w_IQR, x_IQR, y_IQR, z_IQR, label]


    stat_df_orientation.loc[len(stat_df_orientation)] = new_row

for i, g in grouped_data:
    
    x_mean = g['GravityX'].mean()
    y_mean = g['GravityY'].mean()
    z_mean = g['GravityZ'].mean()

    x_std = g['GravityX'].std()
    y_std = g['GravityY'].std()
    z_std = g['GravityZ'].std()

    x_average_absolute_diff = (abs(g['GravityX'] - g['GravityX'].mean())).mean()
    y_average_absolute_diff = (abs(g['GravityY'] - g['GravityY'].mean())).mean()
    z_average_absolute_diff = (abs(g['GravityZ'] - g['GravityZ'].mean())).mean()

    x_min = g['GravityX'].min()
    y_min = g['GravityY'].min()
    z_min = g['GravityZ'].min()

    x_max = g['GravityX'].max()
    y_max = g['GravityY'].max()
    z_max = g['GravityZ'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min

    x_median = g['GravityX'].median()
    y_median = g['GravityY'].median()
    z_median = g['GravityZ'].median()

    x_mad = (abs(g['GravityX'] - x_median)).median()
    y_mad = (abs(g['GravityY'] - y_median)).median()
    z_mad = (abs(g['GravityZ'] - z_median)).median()

    x_IQR = g['GravityX'].describe()['75%'] - g['GravityX'].describe()['25%']
    y_IQR = g['GravityY'].describe()['75%'] - g['GravityY'].describe()['25%']
    z_IQR = g['GravityZ'].describe()['75%'] - g['GravityZ'].describe()['25%']

    #calculate most common label in the window
    label = g['Category'].max()

    new_row = [x_mean, y_mean, z_mean, x_std, y_std, z_std, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff,                         x_min, y_min, z_min, x_max, y_max, z_max, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, x_median, y_median, z_median, x_mad,                         y_mad, z_mad, x_IQR, y_IQR, z_IQR, label]

    stat_df_gravity.loc[len(stat_df_gravity)] = new_row

for i, g in grouped_data:
    
    x_mean = g['LAccelerationX'].mean()
    y_mean = g['LAccelerationY'].mean()
    z_mean = g['LAccelerationZ'].mean()

    x_std = g['LAccelerationX'].std()
    y_std = g['LAccelerationY'].std()
    z_std = g['LAccelerationZ'].std()

    x_average_absolute_diff = (abs(g['LAccelerationX'] - g['LAccelerationX'].mean())).mean()
    y_average_absolute_diff = (abs(g['LAccelerationY'] - g['LAccelerationY'].mean())).mean()
    z_average_absolute_diff = (abs(g['LAccelerationZ'] - g['LAccelerationZ'].mean())).mean()

    x_min = g['LAccelerationX'].min()
    y_min = g['LAccelerationY'].min()
    z_min = g['LAccelerationZ'].min()

    x_max = g['LAccelerationX'].max()
    y_max = g['LAccelerationY'].max()
    z_max = g['LAccelerationZ'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min

    x_median = g['LAccelerationX'].median()
    y_median = g['LAccelerationY'].median()
    z_median = g['LAccelerationZ'].median()

    x_mad = (abs(g['LAccelerationX'] - x_median)).median()
    y_mad = (abs(g['LAccelerationY'] - y_median)).median()
    z_mad = (abs(g['LAccelerationZ'] - z_median)).median()

    x_IQR = g['LAccelerationX'].describe()['75%'] - g['LAccelerationX'].describe()['25%']
    y_IQR = g['LAccelerationY'].describe()['75%'] - g['LAccelerationY'].describe()['25%']
    z_IQR = g['LAccelerationZ'].describe()['75%'] - g['LAccelerationZ'].describe()['25%']

    #calculate most common label in the window
    label = g['Category'].max()

    new_row = [x_mean, y_mean, z_mean, x_std, y_std, z_std, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff,                         x_min, y_min, z_min, x_max, y_max, z_max, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, x_median, y_median, z_median, x_mad,                         y_mad, z_mad, x_IQR, y_IQR, z_IQR, label]

    stat_df_lacceleration.loc[len(stat_df_lacceleration)] = new_row

for i, g in grouped_data:

    mean = g['Pressure'].mean()
    std = g['Pressure'].std()
    average_absolute_diff = (abs(g['Pressure'] - g['Pressure'].mean())).mean()
    min = g['Pressure'].min()
    max = g['Pressure'].max()
    maxmin_diff = max - min
    median = g['Pressure'].median()
    mad = (abs(g['Pressure'] - median)).median()
    IQR = g['Pressure'].describe()['75%'] - g['Pressure'].describe()['25%']

    #calculate most common label in the window
    label = g['Category'].max()

    new_row = [mean, std, average_absolute_diff, min, max, maxmin_diff, median, mad, IQR, label]

    stat_df_pressure.loc[len(stat_df_pressure)] = new_row

for i, g in grouped_data:

    mean = g['AltitudePS'].mean()
    std = g['AltitudePS'].std()
    average_absolute_diff = (abs(g['AltitudePS'] - g['AltitudePS'].mean())).mean()
    min = g['AltitudePS'].min()
    max = g['AltitudePS'].max()
    maxmin_diff = max - min
    median = g['AltitudePS'].median()
    mad = (abs(g['AltitudePS'] - median)).median()
    IQR = g['AltitudePS'].describe()['75%'] - g['AltitudePS'].describe()['25%']

    #calculate most common label in the window
    label = g['Category'].max()

    new_row = [mean, std, average_absolute_diff, min, max, maxmin_diff, median, mad, IQR, label]

    stat_df_altitude.loc[len(stat_df_altitude)] = new_row

for i, g in grouped_data:
    mean = g['TemperaturePS'].mean()
    std = g['TemperaturePS'].std()
    average_absolute_diff = (abs(g['TemperaturePS'] - g['TemperaturePS'].mean())).mean()
    min = g['TemperaturePS'].min()
    max = g['TemperaturePS'].max()
    maxmin_diff = max - min
    median = g['TemperaturePS'].median()
    mad = (abs(g['TemperaturePS'] - median)).median()
    IQR = g['TemperaturePS'].describe()['75%'] - g['TemperaturePS'].describe()['25%']

    #calculate most common label in the window
    label = g['Category'].max()

    new_row = [mean, std, average_absolute_diff, min, max, maxmin_diff, median, mad, IQR, label]

    stat_df_temperature.loc[len(stat_df_temperature)] = new_row



# correlation calculations
print("------------------Acceleration stats: ------------------")
transportation_type_corr_acceleration = stat_df_acceleration.corrwith(stat_df_acceleration["label"])
print(transportation_type_corr_acceleration.mean())
print("------------------Gyroscope stats: ------------------")
transportation_type_corr_gyroscope = stat_df_gyroscope.corrwith(stat_df_gyroscope["label"])
print(transportation_type_corr_gyroscope.mean())
print("------------------Magnometer stats: ------------------")
transportation_type_corr_magnometer = stat_df_magnometer.corrwith(stat_df_magnometer["label"])
print(transportation_type_corr_magnometer.mean())
print("------------------Orientation stats: ------------------")
transportation_type_corr_orientation = stat_df_orientation.corrwith(stat_df_orientation["label"])
print(transportation_type_corr_orientation.mean())
print("------------------Gravity stats: ------------------")
transportation_type_corr_gravity = stat_df_gravity.corrwith(stat_df_gravity["label"])
print(transportation_type_corr_gravity.mean())
print("------------------lacceleration stats: ------------------")
transportation_type_corr_lacceleration = stat_df_lacceleration.corrwith(stat_df_lacceleration["label"])
print(transportation_type_corr_lacceleration.mean())
print("------------------Pressure stats: ------------------")
transportation_type_corr_pressure = stat_df_pressure.corrwith(stat_df_pressure["label"])
print(transportation_type_corr_pressure.mean())
print("------------------Altitude stats: ------------------")
transportation_type_corr_altitude = stat_df_altitude.corrwith(stat_df_altitude["label"])
print(transportation_type_corr_altitude.mean())
print("------------------Temperature stats: ------------------")
transportation_type_corr_temperature = stat_df_temperature.corrwith(stat_df_temperature["label"])
print(transportation_type_corr_temperature.mean())

# print the correlations
