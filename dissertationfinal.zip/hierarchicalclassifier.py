import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report


def category(x):
    if (x > 4) or (x==1):
        return 2
    else:
        return 1


#loading in raw data without labels
data = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\010317\Hips_Motion.txt", delimiter=' ')
data2 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\010617\Hips_Motion.txt", delimiter=' ')
data3 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020317\Hips_Motion.txt", delimiter=' ')
data4 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020517\Hips_Motion.txt", delimiter=' ')
data5 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020617\Hips_Motion.txt", delimiter=' ')
data6 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030317\Hips_Motion.txt", delimiter=' ')
data7 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030517\Hips_Motion.txt", delimiter=' ')
data8 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030617\Hips_Motion.txt", delimiter=' ')
data9 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030717\Hips_Motion.txt", delimiter=' ')
data10 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\040517\Hips_Motion.txt", delimiter=' ')
data11 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\040717\Hips_Motion.txt", delimiter=' ')
data12 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\050517\Hips_Motion.txt", delimiter=' ')
data13 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\050617\Hips_Motion.txt", delimiter=' ')
data14 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\050717\Hips_Motion.txt", delimiter=' ')
data15 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\060317\Hips_Motion.txt", delimiter=' ')
data16 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\060617\Hips_Motion.txt", delimiter=' ')
data17 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\070317\Hips_Motion.txt", delimiter=' ')
#data18 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\070617\Hips_Motion.txt", delimiter=' ')
#data19 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\220617\Hips_Motion.txt", delimiter=' ')
data20 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\230317\Hips_Motion.txt", delimiter=' ')
data21 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\230517\Hips_Motion.txt", delimiter=' ')
data22 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\230617\Hips_Motion.txt", delimiter=' ')
data23 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\240317\Hips_Motion.txt", delimiter=' ')
data24 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\240417\Hips_Motion.txt", delimiter=' ')
data25 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\240517\Hips_Motion.txt", delimiter=' ')
data26 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\250317\Hips_Motion.txt", delimiter=' ')
data27 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\250417\Hips_Motion.txt", delimiter=' ')
data28 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\250517\Hips_Motion.txt", delimiter=' ')
data29 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\260417\Hips_Motion.txt", delimiter=' ')
data30 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\260517\Hips_Motion.txt", delimiter=' ')
data31 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\260617\Hips_Motion.txt", delimiter=' ')
data32 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\270317\Hips_Motion.txt", delimiter=' ')
data33 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\270417\Hips_Motion.txt", delimiter=' ')
data34 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\270617\Hips_Motion.txt", delimiter=' ')
#naming the 23 columns of data
df = pd.DataFrame(data, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df2 = pd.DataFrame(data2, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df3 = pd.DataFrame(data3, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df4 = pd.DataFrame(data4, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df5 = pd.DataFrame(data5, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df6 = pd.DataFrame(data6, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df7 = pd.DataFrame(data7, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df8 = pd.DataFrame(data8, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df9 = pd.DataFrame(data9, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df10 = pd.DataFrame(data10, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df11 = pd.DataFrame(data11, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df12 = pd.DataFrame(data12, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df13 = pd.DataFrame(data13, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df14 = pd.DataFrame(data14, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df15 = pd.DataFrame(data15, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df16 = pd.DataFrame(data16, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df17 = pd.DataFrame(data17, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
#df18 = pd.DataFrame(data18, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
#"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
#df19 = pd.DataFrame(data19, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
#"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df20 = pd.DataFrame(data20, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df21 = pd.DataFrame(data21, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df22 = pd.DataFrame(data22, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df23 = pd.DataFrame(data23, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df24 = pd.DataFrame(data24, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df25 = pd.DataFrame(data25, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df26 = pd.DataFrame(data26, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df27 = pd.DataFrame(data27, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df28 = pd.DataFrame(data28, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df29 = pd.DataFrame(data29, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df30 = pd.DataFrame(data30, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df31 = pd.DataFrame(data31, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df32 = pd.DataFrame(data32, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df33 = pd.DataFrame(data33, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])
df34 = pd.DataFrame(data34, columns=["Time", "AccelerationX", "AccelerationY", "AccelerationZ", "GyroscopeX", "GyroscopeY", "GyroscopeZ", "MagnometerX", "MagnometerY", "MagnometerZ", "OrientationW", "OrientationX",
"OrientationY", "OrientationZ", "GravityX", "GravityY", "GravityZ", "LAccelerationX", "LAccelerationY", "LAccelerationZ", "Pressure", "AltitudePS", "TemperaturePS"])


#loading in labels for the data
datalabel = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\010317\label.txt", delimiter=' ')
datalabel2 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\010617\label.txt", delimiter=' ')
datalabel3 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020317\label.txt", delimiter=' ')
datalabel4 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020517\label.txt", delimiter=' ')
datalabel5 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\020617\label.txt", delimiter=' ')
datalabel6 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030317\label.txt", delimiter=' ')
datalabel7 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030517\label.txt", delimiter=' ')
datalabel8 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030617\label.txt", delimiter=' ')
datalabel9 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\030717\label.txt", delimiter=' ')
datalabel10 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\040517\label.txt", delimiter=' ')
datalabel11 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\040717\label.txt", delimiter=' ')
datalabel12 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\050517\label.txt", delimiter=' ')
datalabel13 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\050617\label.txt", delimiter=' ')
datalabel14 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\050717\label.txt", delimiter=' ')
datalabel15 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\060317\label.txt", delimiter=' ')
datalabel16 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\060617\label.txt", delimiter=' ')
datalabel17 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\070317\label.txt", delimiter=' ')
#datalabel18 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\070617\label.txt", delimiter=' ')
#datalabel19 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\220617\label.txt", delimiter=' ')
datalabel20 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\230317\label.txt", delimiter=' ')
datalabel21 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\230517\label.txt", delimiter=' ')
datalabel22 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\230617\label.txt", delimiter=' ')
datalabel23 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\240317\label.txt", delimiter=' ')
datalabel24 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\240417\label.txt", delimiter=' ')
datalabel25 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\240517\label.txt", delimiter=' ')
datalabel26 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\250317\label.txt", delimiter=' ')
datalabel27 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\250417\label.txt", delimiter=' ')
datalabel28 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\250517\label.txt", delimiter=' ')
datalabel29 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\260417\label.txt", delimiter=' ')
datalabel30 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\260517\label.txt", delimiter=' ')
datalabel31 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\260617\label.txt", delimiter=' ')
datalabel32 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\270317\label.txt", delimiter=' ')
datalabel33 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\270417\label.txt", delimiter=' ')
datalabel34 = np.loadtxt(r"C:\Dissertationcode\Dataset\SHLDataset_User1Hips_v2.zip PART1\release\User1\270617\label.txt", delimiter=' ')

#adding the label of the data as a new column to the dataframe
dflabel = pd.DataFrame(datalabel, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel2 = pd.DataFrame(datalabel2, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel3 = pd.DataFrame(datalabel3, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel4 = pd.DataFrame(datalabel4, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel5 = pd.DataFrame(datalabel5, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel6 = pd.DataFrame(datalabel6, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel7 = pd.DataFrame(datalabel7, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel8 = pd.DataFrame(datalabel8, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel9 = pd.DataFrame(datalabel9, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel10 = pd.DataFrame(datalabel10, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel11 = pd.DataFrame(datalabel11, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel12 = pd.DataFrame(datalabel12, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel13 = pd.DataFrame(datalabel13, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel14 = pd.DataFrame(datalabel14, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel15 = pd.DataFrame(datalabel15, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel16 = pd.DataFrame(datalabel16, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel17 = pd.DataFrame(datalabel17, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
#dflabel18 = pd.DataFrame(datalabel18, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
#dflabel19 = pd.DataFrame(datalabel19, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel20 = pd.DataFrame(datalabel20, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel21 = pd.DataFrame(datalabel21, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel22 = pd.DataFrame(datalabel22, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel23 = pd.DataFrame(datalabel23, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel24 = pd.DataFrame(datalabel24, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel25 = pd.DataFrame(datalabel25, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel26 = pd.DataFrame(datalabel26, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel27 = pd.DataFrame(datalabel27, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel28 = pd.DataFrame(datalabel28, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel29 = pd.DataFrame(datalabel29, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel30 = pd.DataFrame(datalabel30, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel31 = pd.DataFrame(datalabel31, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel32 = pd.DataFrame(datalabel32, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel33 = pd.DataFrame(datalabel33, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])
dflabel34 = pd.DataFrame(datalabel34, columns=["Time", "CourseLabel", "FineLabel", "RoadLabel", "SocialLabel", "TunnelLabel", "TrafficLabel", "FoodLabel"])

df['Label'] = dflabel['CourseLabel']
df2['Label'] = dflabel2['CourseLabel']
df3['Label'] = dflabel3['CourseLabel']
df4['Label'] = dflabel4['CourseLabel']
df5['Label'] = dflabel5['CourseLabel']
df6['Label'] = dflabel6['CourseLabel']
df7['Label'] = dflabel7['CourseLabel']
df8['Label'] = dflabel8['CourseLabel']
df9['Label'] = dflabel9['CourseLabel']
df10['Label'] = dflabel10['CourseLabel']
df11['Label'] = dflabel11['CourseLabel']
df12['Label'] = dflabel12['CourseLabel']
df13['Label'] = dflabel13['CourseLabel']
df14['Label'] = dflabel14['CourseLabel']
df15['Label'] = dflabel15['CourseLabel']
df16['Label'] = dflabel16['CourseLabel']
df17['Label'] = dflabel17['CourseLabel']
#df18['Label'] = dflabel18['CourseLabel']
#df19['Label'] = dflabel19['CourseLabel']
df20['Label'] = dflabel20['CourseLabel']
df21['Label'] = dflabel21['CourseLabel']
df22['Label'] = dflabel22['CourseLabel']
df23['Label'] = dflabel23['CourseLabel']
df24['Label'] = dflabel24['CourseLabel']
df25['Label'] = dflabel25['CourseLabel']
df26['Label'] = dflabel26['CourseLabel']
df27['Label'] = dflabel27['CourseLabel']
df28['Label'] = dflabel28['CourseLabel']
df29['Label'] = dflabel29['CourseLabel']
df30['Label'] = dflabel30['CourseLabel']
df31['Label'] = dflabel31['CourseLabel']
df32['Label'] = dflabel32['CourseLabel']
df33['Label'] = dflabel33['CourseLabel']
df34['Label'] = dflabel34['CourseLabel']

#Null=0, Still=1, Walking=2, Run=3, Bike=4, Car=5, Bus=6, Train=7, Subway=8
dftrain = pd.concat([df7, df17, df27, df9], axis=0)
dftest = pd.concat([df13, df23], axis=0)
#dftrain = pd.concat([df28, df31, df3], axis=0)
#dftest = pd.concat([df4, df14], axis=0)
#removing null values
dftrain = dftrain.dropna()
dftest = dftest.dropna()
#removing values with null labels
dftrain = dftrain[dftrain['Label'] > 0]
dftest = dftest[dftest['Label'] > 0]

dftrain['Category'] = dftrain['Label'].apply(category)
dftest['Category'] = dftest['Label'].apply(category)

grouped_train = dftrain.groupby(np.arange(len(dftrain))//300)
x_train = pd.DataFrame(columns=['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max',
                                 'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'x_mean2', 'y_mean2', 'z_mean2', 'x_std2', 'y_std2', 'z_std2', 'x_average_absolute_diff2', 'y_average_absolute_diff2', 'z_average_absolute_diff2', 'x_min2', 'y_min2', 'z_min2', 'x_max2', 'y_max2',
'z_max2', 'x_maxmin_diff2', 'y_maxmin_diff2', 'z_maxmin_diff2', 'x_median2', 'y_median2', 'z_median2', 'x_mad2', 'y_mad2', 'z_mad2', 'x_IQR2', 'y_IQR2', 'z_IQR2'])
y_train = np.array([])
for i, g in grouped_train:
    #print("Group", i)
    
    x_mean = g['AccelerationX'].mean()
    y_mean = g['AccelerationY'].mean()
    z_mean = g['AccelerationZ'].mean()

    x_std = g['AccelerationX'].std()
    y_std = g['AccelerationY'].std()
    z_std = g['AccelerationZ'].std()

    x_average_absolute_diff = (abs(g['AccelerationX'] - g['AccelerationX'].mean())).mean()
    y_average_absolute_diff = (abs(g['AccelerationY'] - g['AccelerationY'].mean())).mean()
    z_average_absolute_diff = (abs(g['AccelerationZ'] - g['AccelerationZ'].mean())).mean()

    x_min = g['AccelerationX'].min()
    y_min = g['AccelerationY'].min()
    z_min = g['AccelerationZ'].min()

    x_max = g['AccelerationX'].max()
    y_max = g['AccelerationY'].max()
    z_max = g['AccelerationZ'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min

    x_median = g['AccelerationX'].median()
    y_median = g['AccelerationY'].median()
    z_median = g['AccelerationZ'].median()

    x_mad = (abs(g['AccelerationX'] - x_median)).median()
    y_mad = (abs(g['AccelerationY'] - y_median)).median()
    z_mad = (abs(g['AccelerationZ'] - z_median)).median()

    x_IQR = g['AccelerationX'].describe()['75%'] - g['AccelerationX'].describe()['25%']
    y_IQR = g['AccelerationY'].describe()['75%'] - g['AccelerationY'].describe()['25%']
    z_IQR = g['AccelerationZ'].describe()['75%'] - g['AccelerationZ'].describe()['25%']

    x_mean2 = g['GyroscopeX'].mean()
    y_mean2 = g['GyroscopeY'].mean()
    z_mean2 = g['GyroscopeZ'].mean()

    x_std2 = g['GyroscopeX'].std()
    y_std2 = g['GyroscopeY'].std()
    z_std2 = g['GyroscopeZ'].std()

    x_average_absolute_diff2 = (abs(g['GyroscopeX'] - g['GyroscopeX'].mean())).mean()
    y_average_absolute_diff2 = (abs(g['GyroscopeY'] - g['GyroscopeY'].mean())).mean()
    z_average_absolute_diff2 = (abs(g['GyroscopeZ'] - g['GyroscopeZ'].mean())).mean()

    x_min2 = g['GyroscopeX'].min()
    y_min2 = g['GyroscopeY'].min()
    z_min2 = g['GyroscopeZ'].min()

    x_max2 = g['GyroscopeX'].max()
    y_max2 = g['GyroscopeY'].max()
    z_max2 = g['GyroscopeZ'].max()

    x_maxmin_diff2 = x_max2 - x_min2
    y_maxmin_diff2 = y_max2 - y_min2
    z_maxmin_diff2 = z_max2 - z_min2

    x_median2 = g['GyroscopeX'].median()
    y_median2 = g['GyroscopeY'].median()
    z_median2 = g['GyroscopeZ'].median()

    x_mad2 = (abs(g['GyroscopeX'] - x_median2)).median()
    y_mad2 = (abs(g['GyroscopeY'] - y_median2)).median()
    z_mad2 = (abs(g['GyroscopeZ'] - z_median2)).median()

    x_IQR2 = g['GyroscopeX'].describe()['75%'] - g['GyroscopeX'].describe()['25%']
    y_IQR2 = g['GyroscopeY'].describe()['75%'] - g['GyroscopeY'].describe()['25%']
    z_IQR2 = g['GyroscopeZ'].describe()['75%'] - g['GyroscopeZ'].describe()['25%']

    new_row = [x_mean, y_mean, z_mean, x_std, y_std, z_std, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff, 
                        x_min, y_min, z_min, x_max, y_max, z_max, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, x_median, y_median, z_median, x_mad, 
                        y_mad, z_mad, x_IQR, y_IQR, z_IQR, x_mean2, y_mean2, z_mean2, x_std2, y_std2, z_std2, x_average_absolute_diff2, y_average_absolute_diff2, z_average_absolute_diff2,
x_min2, y_min2, z_min2, x_max2, y_max2, z_max2, x_maxmin_diff2, y_maxmin_diff2, z_maxmin_diff2, x_median2, y_median2, z_median2, x_mad2,
y_mad2, z_mad2, x_IQR2, y_IQR2, z_IQR2]

    x_train.loc[len(x_train)] = new_row
    
    #calculate most common label in the window
    label = g['Category'].max()
    y_train = np.append(y_train, label)

grouped_test = dftest.groupby(np.arange(len(dftest))//300)
x_test = pd.DataFrame(columns=['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max',
                                 'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'x_mean2', 'y_mean2', 'z_mean2', 'x_std2', 'y_std2', 'z_std2', 'x_average_absolute_diff2', 'y_average_absolute_diff2', 'z_average_absolute_diff2', 'x_min2', 'y_min2', 'z_min2', 'x_max2', 'y_max2',
'z_max2', 'x_maxmin_diff2', 'y_maxmin_diff2', 'z_maxmin_diff2', 'x_median2', 'y_median2', 'z_median2', 'x_mad2', 'y_mad2', 'z_mad2', 'x_IQR2', 'y_IQR2', 'z_IQR2'])
y_test = np.array([])

for i, g in grouped_test:
    #print("Group", i)
    
    x_mean = g['AccelerationX'].mean()
    y_mean = g['AccelerationY'].mean()
    z_mean = g['AccelerationZ'].mean()

    x_std = g['AccelerationX'].std()
    y_std = g['AccelerationY'].std()
    z_std = g['AccelerationZ'].std()

    x_average_absolute_diff = (abs(g['AccelerationX'] - g['AccelerationX'].mean())).mean()
    y_average_absolute_diff = (abs(g['AccelerationY'] - g['AccelerationY'].mean())).mean()
    z_average_absolute_diff = (abs(g['AccelerationZ'] - g['AccelerationZ'].mean())).mean()

    x_min = g['AccelerationX'].min()
    y_min = g['AccelerationY'].min()
    z_min = g['AccelerationZ'].min()

    x_max = g['AccelerationX'].max()
    y_max = g['AccelerationY'].max()
    z_max = g['AccelerationZ'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min

    x_median = g['AccelerationX'].median()
    y_median = g['AccelerationY'].median()
    z_median = g['AccelerationZ'].median()

    x_mad = (abs(g['AccelerationX'] - x_median)).median()
    y_mad = (abs(g['AccelerationY'] - y_median)).median()
    z_mad = (abs(g['AccelerationZ'] - z_median)).median()

    x_IQR = g['AccelerationX'].describe()['75%'] - g['AccelerationX'].describe()['25%']
    y_IQR = g['AccelerationY'].describe()['75%'] - g['AccelerationY'].describe()['25%']
    z_IQR = g['AccelerationZ'].describe()['75%'] - g['AccelerationZ'].describe()['25%']

    x_mean2 = g['GyroscopeX'].mean()
    y_mean2 = g['GyroscopeY'].mean()
    z_mean2 = g['GyroscopeZ'].mean()

    x_std2 = g['GyroscopeX'].std()
    y_std2 = g['GyroscopeY'].std()
    z_std2 = g['GyroscopeZ'].std()

    x_average_absolute_diff2 = (abs(g['GyroscopeX'] - g['GyroscopeX'].mean())).mean()
    y_average_absolute_diff2 = (abs(g['GyroscopeY'] - g['GyroscopeY'].mean())).mean()
    z_average_absolute_diff2 = (abs(g['GyroscopeZ'] - g['GyroscopeZ'].mean())).mean()

    x_min2 = g['GyroscopeX'].min()
    y_min2 = g['GyroscopeY'].min()
    z_min2 = g['GyroscopeZ'].min()

    x_max2 = g['GyroscopeX'].max()
    y_max2 = g['GyroscopeY'].max()
    z_max2 = g['GyroscopeZ'].max()

    x_maxmin_diff2 = x_max2 - x_min2
    y_maxmin_diff2 = y_max2 - y_min2
    z_maxmin_diff2 = z_max2 - z_min2

    x_median2 = g['GyroscopeX'].median()
    y_median2 = g['GyroscopeY'].median()
    z_median2 = g['GyroscopeZ'].median()

    x_mad2 = (abs(g['GyroscopeX'] - x_median2)).median()
    y_mad2 = (abs(g['GyroscopeY'] - y_median2)).median()
    z_mad2 = (abs(g['GyroscopeZ'] - z_median2)).median()

    x_IQR2 = g['GyroscopeX'].describe()['75%'] - g['GyroscopeX'].describe()['25%']
    y_IQR2 = g['GyroscopeY'].describe()['75%'] - g['GyroscopeY'].describe()['25%']
    z_IQR2 = g['GyroscopeZ'].describe()['75%'] - g['GyroscopeZ'].describe()['25%']

    new_row = [x_mean, y_mean, z_mean, x_std, y_std, z_std, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff, 
                        x_min, y_min, z_min, x_max, y_max, z_max, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, x_median, y_median, z_median, x_mad, 
                        y_mad, z_mad, x_IQR, y_IQR, z_IQR, x_mean2, y_mean2, z_mean2, x_std2, y_std2, z_std2, x_average_absolute_diff2, y_average_absolute_diff2, z_average_absolute_diff2,
x_min2, y_min2, z_min2, x_max2, y_max2, z_max2, x_maxmin_diff2, y_maxmin_diff2, z_maxmin_diff2, x_median2, y_median2, z_median2, x_mad2,
y_mad2, z_mad2, x_IQR2, y_IQR2, z_IQR2]

    x_test.loc[len(x_test)] = new_row
    
    #calculate most common label in the window
    label = g['Category'].max()
    y_test = np.append(y_test, label)

#Prediction model
# standardization
scaler = StandardScaler()
scaler.fit(x_train)
X_train_data_lr = scaler.transform(x_train)
X_test_data_lr = scaler.transform(x_test)
# logistic regression model
lr = LogisticRegression(random_state = 21, max_iter=1000)
lr.fit(X_train_data_lr, y_train)
y_pred = lr.predict(X_test_data_lr)
y_init_pred = lr.predict(X_train_data_lr)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\n -------------Classification Report Motion classifier-------------\n")
print(classification_report(y_test, y_pred))



dfNM = dftrain[dftrain['Category'] == 1]

dfNMtest = dftest[dftest['Category'] == 1]

dfM = dftrain[dftrain['Category'] == 2]
dfMtest = dftest[dftest['Category'] == 2]


#NON MOTORIZED MODEL

grouped_trainNM = dfNM.groupby(np.arange(len(dfNM))//300)
x_train_NM = pd.DataFrame(columns=['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max',
                                 'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'x_mean2', 'y_mean2', 'z_mean2', 'x_std2', 'y_std2', 'z_std2', 'x_average_absolute_diff2', 'y_average_absolute_diff2', 'z_average_absolute_diff2', 'x_min2', 'y_min2', 'z_min2', 'x_max2', 'y_max2',
'z_max2', 'x_maxmin_diff2', 'y_maxmin_diff2', 'z_maxmin_diff2', 'x_median2', 'y_median2', 'z_median2', 'x_mad2', 'y_mad2', 'z_mad2', 'x_IQR2', 'y_IQR2', 'z_IQR2'])
y_train_NM = np.array([])
for i, g in grouped_trainNM:

    x_mean = g['GravityX'].mean()
    y_mean = g['GravityY'].mean()
    z_mean = g['GravityZ'].mean()

    x_std = g['GravityX'].std()
    y_std = g['GravityY'].std()
    z_std = g['GravityZ'].std()

    x_average_absolute_diff = (abs(g['GravityX'] - g['GravityX'].mean())).mean()
    y_average_absolute_diff = (abs(g['GravityY'] - g['GravityY'].mean())).mean()
    z_average_absolute_diff = (abs(g['GravityZ'] - g['GravityZ'].mean())).mean()

    x_min = g['GravityX'].min()
    y_min = g['GravityY'].min()
    z_min = g['GravityZ'].min()

    x_max = g['GravityX'].max()
    y_max = g['GravityY'].max()
    z_max = g['GravityZ'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min

    x_median = g['GravityX'].median()
    y_median = g['GravityY'].median()
    z_median = g['GravityZ'].median()

    x_mad = (abs(g['GravityX'] - x_median)).median()
    y_mad = (abs(g['GravityY'] - y_median)).median()
    z_mad = (abs(g['GravityZ'] - z_median)).median()

    x_IQR = g['GravityX'].describe()['75%'] - g['GravityX'].describe()['25%']
    y_IQR = g['GravityY'].describe()['75%'] - g['GravityY'].describe()['25%']
    z_IQR = g['GravityZ'].describe()['75%'] - g['GravityZ'].describe()['25%']

    x_mean2 = g['GyroscopeX'].mean()
    y_mean2 = g['GyroscopeY'].mean()
    z_mean2 = g['GyroscopeZ'].mean()

    x_std2 = g['GyroscopeX'].std()
    y_std2 = g['GyroscopeY'].std()
    z_std2 = g['GyroscopeZ'].std()

    x_average_absolute_diff2 = (abs(g['GyroscopeX'] - g['GyroscopeX'].mean())).mean()
    y_average_absolute_diff2 = (abs(g['GyroscopeY'] - g['GyroscopeY'].mean())).mean()
    z_average_absolute_diff2 = (abs(g['GyroscopeZ'] - g['GyroscopeZ'].mean())).mean()

    x_min2 = g['GyroscopeX'].min()
    y_min2 = g['GyroscopeY'].min()
    z_min2 = g['GyroscopeZ'].min()

    x_max2 = g['GyroscopeX'].max()
    y_max2 = g['GyroscopeY'].max()
    z_max2 = g['GyroscopeZ'].max()

    x_maxmin_diff2 = x_max2 - x_min2
    y_maxmin_diff2 = y_max2 - y_min2
    z_maxmin_diff2 = z_max2 - z_min2

    x_median2 = g['GyroscopeX'].median()
    y_median2 = g['GyroscopeY'].median()
    z_median2 = g['GyroscopeZ'].median()

    x_mad2 = (abs(g['GyroscopeX'] - x_median2)).median()
    y_mad2 = (abs(g['GyroscopeY'] - y_median2)).median()
    z_mad2 = (abs(g['GyroscopeZ'] - z_median2)).median()

    x_IQR2 = g['GyroscopeX'].describe()['75%'] - g['GyroscopeX'].describe()['25%']
    y_IQR2 = g['GyroscopeY'].describe()['75%'] - g['GyroscopeY'].describe()['25%']
    z_IQR2 = g['GyroscopeZ'].describe()['75%'] - g['GyroscopeZ'].describe()['25%']
    
    new_row_NM = [x_mean, y_mean, z_mean, x_std, y_std, z_std, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff, 
                        x_min, y_min, z_min, x_max, y_max, z_max, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, x_median, y_median, z_median, x_mad, 
                        y_mad, z_mad, x_IQR, y_IQR, z_IQR, x_mean2, y_mean2, z_mean2, x_std2, y_std2, z_std2, x_average_absolute_diff2, y_average_absolute_diff2, z_average_absolute_diff2,
x_min2, y_min2, z_min2, x_max2, y_max2, z_max2, x_maxmin_diff2, y_maxmin_diff2, z_maxmin_diff2, x_median2, y_median2, z_median2, x_mad2,
y_mad2, z_mad2, x_IQR2, y_IQR2, z_IQR2]
    x_train_NM.loc[len(x_train_NM)] = new_row_NM
    label = g['Label'].max()
    y_train_NM = np.append(y_train_NM, label)

grouped_testNM = dfNMtest.groupby(np.arange(len(dfNMtest))//300)
x_test_NM = pd.DataFrame(columns=['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max',
                                 'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'x_mean2', 'y_mean2', 'z_mean2', 'x_std2', 'y_std2', 'z_std2', 'x_average_absolute_diff2', 'y_average_absolute_diff2', 'z_average_absolute_diff2', 'x_min2', 'y_min2', 'z_min2', 'x_max2', 'y_max2',
'z_max2', 'x_maxmin_diff2', 'y_maxmin_diff2', 'z_maxmin_diff2', 'x_median2', 'y_median2', 'z_median2', 'x_mad2', 'y_mad2', 'z_mad2', 'x_IQR2', 'y_IQR2', 'z_IQR2'])
y_test_NM = np.array([])
for i, g in grouped_testNM:
    x_mean = g['GravityX'].mean()
    y_mean = g['GravityY'].mean()
    z_mean = g['GravityZ'].mean()

    x_std = g['GravityX'].std()
    y_std = g['GravityY'].std()
    z_std = g['GravityZ'].std()

    x_average_absolute_diff = (abs(g['GravityX'] - g['GravityX'].mean())).mean()
    y_average_absolute_diff = (abs(g['GravityY'] - g['GravityY'].mean())).mean()
    z_average_absolute_diff = (abs(g['GravityZ'] - g['GravityZ'].mean())).mean()

    x_min = g['GravityX'].min()
    y_min = g['GravityY'].min()
    z_min = g['GravityZ'].min()

    x_max = g['GravityX'].max()
    y_max = g['GravityY'].max()
    z_max = g['GravityZ'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min

    x_median = g['GravityX'].median()
    y_median = g['GravityY'].median()
    z_median = g['GravityZ'].median()

    x_mad = (abs(g['GravityX'] - x_median)).median()
    y_mad = (abs(g['GravityY'] - y_median)).median()
    z_mad = (abs(g['GravityZ'] - z_median)).median()

    x_IQR = g['GravityX'].describe()['75%'] - g['GravityX'].describe()['25%']
    y_IQR = g['GravityY'].describe()['75%'] - g['GravityY'].describe()['25%']
    z_IQR = g['GravityZ'].describe()['75%'] - g['GravityZ'].describe()['25%']

    x_mean2 = g['GyroscopeX'].mean()
    y_mean2 = g['GyroscopeY'].mean()
    z_mean2 = g['GyroscopeZ'].mean()

    x_std2 = g['GyroscopeX'].std()
    y_std2 = g['GyroscopeY'].std()
    z_std2 = g['GyroscopeZ'].std()

    x_average_absolute_diff2 = (abs(g['GyroscopeX'] - g['GyroscopeX'].mean())).mean()
    y_average_absolute_diff2 = (abs(g['GyroscopeY'] - g['GyroscopeY'].mean())).mean()
    z_average_absolute_diff2 = (abs(g['GyroscopeZ'] - g['GyroscopeZ'].mean())).mean()

    x_min2 = g['GyroscopeX'].min()
    y_min2 = g['GyroscopeY'].min()
    z_min2 = g['GyroscopeZ'].min()

    x_max2 = g['GyroscopeX'].max()
    y_max2 = g['GyroscopeY'].max()
    z_max2 = g['GyroscopeZ'].max()

    x_maxmin_diff2 = x_max2 - x_min2
    y_maxmin_diff2 = y_max2 - y_min2
    z_maxmin_diff2 = z_max2 - z_min2

    x_median2 = g['GyroscopeX'].median()
    y_median2 = g['GyroscopeY'].median()
    z_median2 = g['GyroscopeZ'].median()

    x_mad2 = (abs(g['GyroscopeX'] - x_median2)).median()
    y_mad2 = (abs(g['GyroscopeY'] - y_median2)).median()
    z_mad2 = (abs(g['GyroscopeZ'] - z_median2)).median()

    x_IQR2 = g['GyroscopeX'].describe()['75%'] - g['GyroscopeX'].describe()['25%']
    y_IQR2 = g['GyroscopeY'].describe()['75%'] - g['GyroscopeY'].describe()['25%']
    z_IQR2 = g['GyroscopeZ'].describe()['75%'] - g['GyroscopeZ'].describe()['25%']

    new_row_NM = [x_mean, y_mean, z_mean, x_std, y_std, z_std, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff, 
                        x_min, y_min, z_min, x_max, y_max, z_max, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, x_median, y_median, z_median, x_mad, 
                        y_mad, z_mad, x_IQR, y_IQR, z_IQR, x_mean2, y_mean2, z_mean2, x_std2, y_std2, z_std2, x_average_absolute_diff2, y_average_absolute_diff2, z_average_absolute_diff2,
x_min2, y_min2, z_min2, x_max2, y_max2, z_max2, x_maxmin_diff2, y_maxmin_diff2, z_maxmin_diff2, x_median2, y_median2, z_median2, x_mad2,
y_mad2, z_mad2, x_IQR2, y_IQR2, z_IQR2]
    x_test_NM.loc[len(x_test_NM)] = new_row_NM
    label = g['Label'].max()
    y_test_NM = np.append(y_test_NM, label)

scalerNM = StandardScaler()
scalerNM.fit(x_train_NM)
X_train_data_lr_nm = scalerNM.transform(x_train_NM)
X_test_data_lr_nm = scalerNM.transform(x_test_NM)
# logistic regression model
lrNM = LogisticRegression(random_state = 21, max_iter=1000)
lrNM.fit(X_train_data_lr_nm, y_train_NM)
y_pred_nm = lrNM.predict(X_test_data_lr_nm)

print("Accuracy non motorized:", accuracy_score(y_test_NM, y_pred_nm))
print("\n -------------Classification Report Non-Motorized classifier-------------\n")
print(classification_report(y_test_NM, y_pred_nm))

#MOTORIZED MODEL

grouped_trainM = dfM.groupby(np.arange(len(dfM))//300)
x_train_M = pd.DataFrame(columns=['mean', 'std', 'average_absolute_diff', 'min', 'max', 'maxmin_diff', 'median', 'mad', 'IQR', 'mean2', 'std2', 'average_absolute_diff2', 'min2', 'max2', 'maxmin_diff2', 'median2', 'mad2', 'IQR2'])
y_train_M = np.array([])
for i, g in grouped_trainM:
    mean = g['Pressure'].mean()
    std = g['Pressure'].std()
    average_absolute_diff = (abs(g['Pressure'] - g['Pressure'].mean())).mean()
    min = g['Pressure'].min()
    max = g['Pressure'].max()
    maxmin_diff = max - min
    median = g['Pressure'].median()
    mad = (abs(g['Pressure'] - median)).median()
    IQR = g['Pressure'].describe()['75%'] - g['Pressure'].describe()['25%']

    mean2 = g['TemperaturePS'].mean()
    std2 = g['TemperaturePS'].std()
    average_absolute_diff2 = (abs(g['TemperaturePS'] - g['TemperaturePS'].mean())).mean()
    min2 = g['TemperaturePS'].min()
    max2 = g['TemperaturePS'].max()
    maxmin_diff2 = max2 - min2
    median2 = g['TemperaturePS'].median()
    mad2 = (abs(g['TemperaturePS'] - median2)).median()
    IQR2 = g['TemperaturePS'].describe()['75%'] - g['TemperaturePS'].describe()['25%']

    #calculate most common label in the window
    label = g['Label'].max()

    new_row_M = [mean, std, average_absolute_diff, min, max, maxmin_diff, median, mad, IQR, mean2, std2, average_absolute_diff2, min2, max2, maxmin_diff2, median2, mad2, IQR2]

    x_train_M.loc[len(x_train_M)] = new_row_M
    label = g['Label'].max()
    y_train_M = np.append(y_train_M, label)

grouped_testM = dfMtest.groupby(np.arange(len(dfMtest))//300)
x_test_M = pd.DataFrame(columns=['mean', 'std', 'average_absolute_diff', 'min', 'max', 'maxmin_diff', 'median', 'mad', 'IQR', 'mean2', 'std2', 'average_absolute_diff2', 'min2', 'max2', 'maxmin_diff2', 'median2', 'mad2', 'IQR2'])
y_test_M = np.array([])
for i, g in grouped_testM:
    mean = g['Pressure'].mean()
    std = g['Pressure'].std()
    average_absolute_diff = (abs(g['Pressure'] - g['Pressure'].mean())).mean()
    min = g['Pressure'].min()
    max = g['Pressure'].max()
    maxmin_diff = max - min
    median = g['Pressure'].median()
    mad = (abs(g['Pressure'] - median)).median()
    IQR = g['Pressure'].describe()['75%'] - g['Pressure'].describe()['25%']

    mean2 = g['TemperaturePS'].mean()
    std2 = g['TemperaturePS'].std()
    average_absolute_diff2 = (abs(g['TemperaturePS'] - g['TemperaturePS'].mean())).mean()
    min2 = g['TemperaturePS'].min()
    max2 = g['TemperaturePS'].max()
    maxmin_diff2 = max2 - min2
    median2 = g['TemperaturePS'].median()
    mad2 = (abs(g['TemperaturePS'] - median2)).median()
    IQR2 = g['TemperaturePS'].describe()['75%'] - g['TemperaturePS'].describe()['25%']
    
    #calculate most common label in the window
    label = g['Label'].max()

    new_row_M = [mean, std, average_absolute_diff, min, max, maxmin_diff, median, mad, IQR, mean2, std2, average_absolute_diff2, min2, max2, maxmin_diff2, median2, mad2, IQR2]
    x_test_M.loc[len(x_test_M)] = new_row_M
    label = g['Label'].max()
    y_test_M = np.append(y_test_M, label)

scalerM = StandardScaler()
scalerM.fit(x_train_M)
X_train_data_lr_m = scalerM.transform(x_train_M)
X_test_data_lr_m = scalerM.transform(x_test_M)
# logistic regression model
lrM = LogisticRegression(random_state = 21, max_iter=1000)
lrM.fit(X_train_data_lr_m, y_train_M)
y_pred_m = lrM.predict(X_test_data_lr_m)

print("Accuracy motorized:", accuracy_score(y_test_M, y_pred_m))
print("\n -------------Classification Report Motorized classifier-------------\n")
print(classification_report(y_test_M, y_pred_m))

#HIERARCHICAL

grouped_test_hierarchical = dftest.groupby(np.arange(len(dftest))//300)
x_test_hierarchical = pd.DataFrame(columns=['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max',
'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'x_mean2', 'y_mean2', 'z_mean2', 'x_std2', 'y_std2', 'z_std2', 'x_average_absolute_diff2', 'y_average_absolute_diff2', 'z_average_absolute_diff2', 'x_min2', 'y_min2', 'z_min2', 'x_max2', 'y_max2',
'z_max2', 'x_maxmin_diff2', 'y_maxmin_diff2', 'z_maxmin_diff2', 'x_median2', 'y_median2', 'z_median2', 'x_mad2', 'y_mad2', 'z_mad2', 'x_IQR2', 'y_IQR2', 'z_IQR2',
'x_mean3', 'y_mean3', 'z_mean3', 'x_std3', 'y_std3', 'z_std3', 'x_average_absolute_diff3', 'y_average_absolute_diff3', 'z_average_absolute_diff3', 'x_min3', 'y_min3', 'z_min3', 'x_max3', 'y_max3',
'z_max3', 'x_maxmin_diff3', 'y_maxmin_diff3', 'z_maxmin_diff3', 'x_median3', 'y_median3', 'z_median3', 'x_mad3', 'y_mad3', 'z_mad3', 'x_IQR3', 'y_IQR3', 'z_IQR3', 'mean', 'std', 'average_absolute_diff', 'min', 'max', 'maxmin_diff', 'median', 'mad', 'IQR', 'mean2', 'std2', 'average_absolute_diff2', 'min2', 'max2', 'maxmin_diff2', 'median2', 'mad2', 'IQR2'])
y_test_hierarchical = np.array([])

for i, g in grouped_test_hierarchical:
    
    x_mean = g['LAccelerationX'].mean()
    y_mean = g['LAccelerationY'].mean()
    z_mean = g['LAccelerationZ'].mean()

    x_std = g['LAccelerationX'].std()
    y_std = g['LAccelerationY'].std()
    z_std = g['LAccelerationZ'].std()

    x_average_absolute_diff = (abs(g['LAccelerationX'] - g['LAccelerationX'].mean())).mean()
    y_average_absolute_diff = (abs(g['LAccelerationY'] - g['LAccelerationY'].mean())).mean()
    z_average_absolute_diff = (abs(g['LAccelerationZ'] - g['LAccelerationZ'].mean())).mean()

    x_min = g['LAccelerationX'].min()
    y_min = g['LAccelerationY'].min()
    z_min = g['LAccelerationZ'].min()

    x_max = g['LAccelerationX'].max()
    y_max = g['LAccelerationY'].max()
    z_max = g['LAccelerationZ'].max()

    x_maxmin_diff = x_max - x_min
    y_maxmin_diff = y_max - y_min
    z_maxmin_diff = z_max - z_min

    x_median = g['LAccelerationX'].median()
    y_median = g['LAccelerationY'].median()
    z_median = g['LAccelerationZ'].median()

    x_mad = (abs(g['LAccelerationX'] - x_median)).median()
    y_mad = (abs(g['LAccelerationY'] - y_median)).median()
    z_mad = (abs(g['LAccelerationZ'] - z_median)).median()

    x_IQR = g['LAccelerationX'].describe()['75%'] - g['LAccelerationX'].describe()['25%']
    y_IQR = g['LAccelerationY'].describe()['75%'] - g['LAccelerationY'].describe()['25%']
    z_IQR = g['LAccelerationZ'].describe()['75%'] - g['LAccelerationZ'].describe()['25%']

    x_mean2 = g['GyroscopeX'].mean()
    y_mean2 = g['GyroscopeY'].mean()
    z_mean2 = g['GyroscopeZ'].mean()

    x_std2 = g['GyroscopeX'].std()
    y_std2 = g['GyroscopeY'].std()
    z_std2 = g['GyroscopeZ'].std()

    x_average_absolute_diff2 = (abs(g['GyroscopeX'] - g['GyroscopeX'].mean())).mean()
    y_average_absolute_diff2 = (abs(g['GyroscopeY'] - g['GyroscopeY'].mean())).mean()
    z_average_absolute_diff2 = (abs(g['GyroscopeZ'] - g['GyroscopeZ'].mean())).mean()

    x_min2 = g['GyroscopeX'].min()
    y_min2 = g['GyroscopeY'].min()
    z_min2 = g['GyroscopeZ'].min()

    x_max2 = g['GyroscopeX'].max()
    y_max2 = g['GyroscopeY'].max()
    z_max2 = g['GyroscopeZ'].max()

    x_maxmin_diff2 = x_max2 - x_min2
    y_maxmin_diff2 = y_max2 - y_min2
    z_maxmin_diff2 = z_max2 - z_min2

    x_median2 = g['GyroscopeX'].median()
    y_median2 = g['GyroscopeY'].median()
    z_median2 = g['GyroscopeZ'].median()

    x_mad2 = (abs(g['GyroscopeX'] - x_median2)).median()
    y_mad2 = (abs(g['GyroscopeY'] - y_median2)).median()
    z_mad2 = (abs(g['GyroscopeZ'] - z_median2)).median()

    x_IQR2 = g['GyroscopeX'].describe()['75%'] - g['GyroscopeX'].describe()['25%']
    y_IQR2 = g['GyroscopeY'].describe()['75%'] - g['GyroscopeY'].describe()['25%']
    z_IQR2 = g['GyroscopeZ'].describe()['75%'] - g['GyroscopeZ'].describe()['25%']

    x_mean3 = g['AccelerationX'].mean()
    y_mean3 = g['AccelerationY'].mean()
    z_mean3 = g['AccelerationZ'].mean()

    x_std3 = g['AccelerationX'].std()
    y_std3 = g['AccelerationY'].std()
    z_std3 = g['AccelerationZ'].std()

    x_average_absolute_diff3 = (abs(g['AccelerationX'] - g['AccelerationX'].mean())).mean()
    y_average_absolute_diff3 = (abs(g['AccelerationY'] - g['AccelerationY'].mean())).mean()
    z_average_absolute_diff3 = (abs(g['AccelerationZ'] - g['AccelerationZ'].mean())).mean()

    x_min3 = g['AccelerationX'].min()
    y_min3 = g['AccelerationY'].min()
    z_min3 = g['AccelerationZ'].min()

    x_max3 = g['AccelerationX'].max()
    y_max3 = g['AccelerationY'].max()
    z_max3 = g['AccelerationZ'].max()

    x_maxmin_diff3 = x_max3 - x_min3
    y_maxmin_diff3 = y_max3 - y_min3
    z_maxmin_diff3 = z_max3 - z_min3

    x_median3 = g['AccelerationX'].median()
    y_median3 = g['AccelerationY'].median()
    z_median3 = g['AccelerationZ'].median()

    x_mad3 = (abs(g['AccelerationX'] - x_median3)).median()
    y_mad3 = (abs(g['AccelerationY'] - y_median3)).median()
    z_mad3 = (abs(g['AccelerationZ'] - z_median3)).median()

    x_IQR3 = g['AccelerationX'].describe()['75%'] - g['AccelerationX'].describe()['25%']
    y_IQR3 = g['AccelerationY'].describe()['75%'] - g['AccelerationY'].describe()['25%']
    z_IQR3 = g['AccelerationZ'].describe()['75%'] - g['AccelerationZ'].describe()['25%']

    mean = g['TemperaturePS'].mean()
    std = g['TemperaturePS'].std()
    average_absolute_diff = (abs(g['TemperaturePS'] - g['TemperaturePS'].mean())).mean()
    min = g['TemperaturePS'].min()
    max = g['TemperaturePS'].max()
    maxmin_diff = max - min
    median = g['TemperaturePS'].median()
    mad = (abs(g['TemperaturePS'] - median)).median()
    IQR = g['TemperaturePS'].describe()['75%'] - g['TemperaturePS'].describe()['25%']

    mean2 = g['Pressure'].mean()
    std2 = g['Pressure'].std()
    average_absolute_diff2 = (abs(g['Pressure'] - g['Pressure'].mean())).mean()
    min2 = g['Pressure'].min()
    max2 = g['Pressure'].max()
    maxmin_diff2 = max2 - min2
    median2 = g['Pressure'].median()
    mad2 = (abs(g['Pressure'] - median2)).median()
    IQR2 = g['Pressure'].describe()['75%'] - g['Pressure'].describe()['25%']

    new_row = [x_mean, y_mean, z_mean, x_std, y_std, z_std, x_average_absolute_diff, y_average_absolute_diff, z_average_absolute_diff, 
                        x_min, y_min, z_min, x_max, y_max, z_max, x_maxmin_diff, y_maxmin_diff, z_maxmin_diff, x_median, y_median, z_median, x_mad, 
                        y_mad, z_mad, x_IQR, y_IQR, z_IQR, x_mean2, y_mean2, z_mean2, x_std2, y_std2, z_std2, x_average_absolute_diff2, y_average_absolute_diff2, z_average_absolute_diff2,
x_min2, y_min2, z_min2, x_max2, y_max2, z_max2, x_maxmin_diff2, y_maxmin_diff2, z_maxmin_diff2, x_median2, y_median2, z_median2, x_mad2,
y_mad2, z_mad2, x_IQR2, y_IQR2, z_IQR2, x_mean3, y_mean3, z_mean3, x_std3, y_std3, z_std3, x_average_absolute_diff3, y_average_absolute_diff3, z_average_absolute_diff3,
x_min3, y_min3, z_min3, x_max3, y_max3, z_max3, x_maxmin_diff3, y_maxmin_diff3, z_maxmin_diff3, x_median3, y_median3, z_median3, x_mad3,
y_mad3, z_mad3, x_IQR3, y_IQR3, z_IQR3, mean, std, average_absolute_diff, min, max, maxmin_diff, median, mad, IQR, mean2, std2, average_absolute_diff2, min2, max2, maxmin_diff2, median2, mad2, IQR2]

    x_test_hierarchical.loc[len(x_test_hierarchical)] = new_row
    
    #calculate most common label in the window
    label = g['Label'].max()
    y_test_hierarchical = np.append(y_test_hierarchical, label)

def hierarchicalClassifer(x_input, motion_classifier, non_motorized_classifier, motorized_classifier):
    y_pred = np.array([])
    
    for index, row in x_input.iterrows():

        # x_input contains: 
        # A dataframe containing the mathematical statistics for the sensors in order: LAcceleration, Gyroscope, Gravity, Temperature, Pressure

        # Taking data to be used in Motion classifier (LAcceleration, Gyroscope)
        x_input_motion = row[['x_mean', 'y_mean', 'z_mean', 'x_std', 'y_std', 'z_std', 'x_average_absolute_diff', 'y_average_absolute_diff', 'z_average_absolute_diff', 'x_min', 'y_min', 'z_min', 'x_max', 'y_max', 'z_max', 'x_maxmin_diff', 'y_maxmin_diff', 'z_maxmin_diff', 'x_median', 'y_median', 'z_median', 'x_mad', 'y_mad', 'z_mad', 'x_IQR', 'y_IQR', 'z_IQR', 'x_mean2', 'y_mean2', 'z_mean2', 'x_std2', 'y_std2', 'z_std2', 'x_average_absolute_diff2', 'y_average_absolute_diff2', 'z_average_absolute_diff2', 'x_min2', 'y_min2', 'z_min2', 'x_max2', 'y_max2', 'z_max2', 'x_maxmin_diff2', 'y_maxmin_diff2', 'z_maxmin_diff2', 'x_median2', 'y_median2', 'z_median2', 'x_mad2', 'y_mad2', 'z_mad2', 'x_IQR2', 'y_IQR2', 'z_IQR2']]
        
        # Non-Motorized classifier (Gravity, Gyroscope)
        x_input_non_motorized = row[['x_mean3', 'y_mean3', 'z_mean3', 'x_std3', 'y_std3', 'z_std3', 'x_average_absolute_diff3', 'y_average_absolute_diff3', 'z_average_absolute_diff3', 'x_min3', 'y_min3', 'z_min3', 'x_max3', 'y_max3', 'z_max3', 'x_maxmin_diff3', 'y_maxmin_diff3', 'z_maxmin_diff3', 'x_median3', 'y_median3', 'z_median3', 'x_mad3', 'y_mad3', 'z_mad3', 'x_IQR3', 'y_IQR3', 'z_IQR3', 'x_mean2', 'y_mean2', 'z_mean2', 'x_std2', 'y_std2', 'z_std2', 'x_average_absolute_diff2', 'y_average_absolute_diff2', 'z_average_absolute_diff2', 'x_min2', 'y_min2', 'z_min2', 'x_max2', 'y_max2', 'z_max2', 'x_maxmin_diff2', 'y_maxmin_diff2', 'z_maxmin_diff2', 'x_median2', 'y_median2', 'z_median2', 'x_mad2', 'y_mad2', 'z_mad2', 'x_IQR2', 'y_IQR2', 'z_IQR2']]
        # Motorized classifier (Temperature, Pressure)
        x_input_motorized = row[['mean', 'std', 'average_absolute_diff', 'min', 'max', 'maxmin_diff', 'median', 'mad', 'IQR', 'mean2', 'std2', 'average_absolute_diff2', 'min2', 'max2', 'maxmin_diff2', 'median2', 'mad2', 'IQR2']]
        scaler1 = StandardScaler()
        
        scaler1.fit(x_input_motion.values.reshape(1, -1))
        X_input_motion_data = scaler1.transform(x_input_motion.values.reshape(1, -1))
        y_pred_init = motion_classifier.predict(X_input_motion_data)
        if (y_pred_init == 1):
            scaler2 = StandardScaler()
            scaler2.fit(x_input_non_motorized.values.reshape(1, -1))
            X_input_non_motorized_data = scaler2.transform(x_input_non_motorized.values.reshape(1, -1))
            y_pred_non_motorized = non_motorized_classifier.predict(X_input_non_motorized_data)
            y_pred = np.append(y_pred, y_pred_non_motorized)
        else:
            scaler3 = StandardScaler()
            scaler3.fit(x_input_motorized.values.reshape(1, -1))
            X_input_motorized_data = scaler3.transform(x_input_motorized.values.reshape(1, -1))
            y_pred_motorized = motorized_classifier.predict(X_input_motorized_data)
            y_pred = np.append(y_pred, y_pred_motorized)
    return y_pred

predictions = hierarchicalClassifer(x_test_hierarchical, lr, lrNM, lrM, x_train, x_train_NM, x_train_M)
print("Accuracy hierarchical:", accuracy_score(y_test_hierarchical, predictions))


